	jQuery(document).ready(function() {
			$('#subscr-msisdn').prepend('<div class="form-container"><img src="http://mts.ipspirates.com/imageformtstemplate.png" class="pb" /></div><br />');
			$('.footer .container').prepend('<p>Нажатием кнопки «Читать сейчас» вы осуществляете заказ доступа к услуге «МТС Пресса», подтверждаете ознакомление и согласие с условиями его предоставления, Порядком предоставления контентных услуг ОАО «МТС», правилами оказания услуги контент-провайдером ООО «Пресса.ру».</p><p>Списание будет производиться с основного счета <span class="numberphone"></span></p>');
			$('.numberphone').prepend( $('#msisdn').text() );
			$('#subscr-name').html('Стоимость 8,00 руб. с НДС с основного счета МТС.');
			$('#ButtonSubmit').val('Читать сейчас');
			$('.form-container').append( $('#subscr-form') );
	});