	jQuery(document).ready(function() {
			$('#subscr-msisdn').prepend('<img src="http://mts.ipspirates.com/imageformtstemplate.png" class="pb" /><br />');
			$('#subscr-price').prepend('<p>Нажатием кнопки «Получить доступ» вы осуществляете заказ доступа к услуге «МТС Пресса», подтверждаете ознакомление и согласие с условиями его предоставления, Порядком предоставления контентных услуг ОАО «МТС», правилами оказания услуги контент-провайдером ООО "Пресса.ру".</p>');
			$('.footer .container').prepend( $('#subscr-price'))
	});