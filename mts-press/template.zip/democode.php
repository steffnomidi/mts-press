<?php include "header.html"; ?>

<h1 id="subscr-name">Доступ к подписке
 &laquo;<span>Демо контент</span>&raquo;</h1>
<div id="subscr-price">Стоимость: <span>10 руб. с НДС за 1 день</span>. <br />Оказывается МТС с привлечением: <span>ООО &quot;Демо провайдер&quot;</span>. <br />Списание будет произведено с основного
 лицевого счета.</div>
<div id="subscr-msisdn">Ваш номер:&nbsp;<span id="msisdn">+79161234567</span></div>
<form id="subscr-form" method="post">
        <div id="activation-code-container">
            <label for="ActivationCode">Введите код активации, полученный в SMS:</label>
            <input autocomplete="off" class="input-validation-error" data-val="true" data-val-required="The ActivationCode field is required." id="ActivationCode" maxlength="4" name="ActivationCode" tabindex="1" type="text" value="">
            <p id="ActivationCode_Validator">* Введите код доступа.</p>
        </div>
    <div id="captcha-container">
    <label>Введите символы с картинки:</label>
        <div class="captcha-main">
            <div class="captcha-i"><img id="captcha-img" class="captcha-img" src="img/image.gif" alt=""></div>
            <div class="f"><img class="arr" src="img/captcha-arrow.gif"><input -class="b-common-ctrl" autocomplete="off" id="Captcha_Value" maxlength="20" name="Captcha.Value" tabindex="2" type="text" value=""></div>
            <div class="captcha-refresh"><span id="c_renew"><img class="captcha-throbber" src="img/next1.gif"><strong>показать другую картинку</strong></span></div>
            <div class="captcha-comment">
                <div id="Captcha_Value_Validator" class="captcha-err">* Необходимо ввести символы с&nbsp;картинки.</div>
                <div id="Captcha_Value_Validator1" class="captcha-err">* Вы неверно ввели символы с&nbsp;картинки</div>
            </div>
        </div>
</div>    <div id="submit-container">
        <label for="ButtonSubmit">Если Вы согласны с условиями оказания услуги, нажмите кнопку <b>«Получить доступ»</b></label>
        <div><input id="ButtonSubmit" type="submit" value="Читать сейчас" onclick="if (!validateActivationForm()) { return false; };"></div>
    </div>
    <input name="__RequestVerificationToken" type="hidden" value="SByuSu92F7DM3jJYGkpM3ZToY70YhIia4xmxobhAHUwj9DXt1qauHVdfZz2sjmgWzPAZZDbLFoH3X0Cpxt7vWJU8koB5RxpLRN-3_nW8I4UwLff48DqGbQ71YHrlXsoY8P_9nVZ72p1ySaVXVOXXlDt8DZJ4l6aEZot0sk2ME_k1">
</form>
<input id="sid" name="sid" type="hidden" value="00000000-0000-0000-0000-000000000000" /><div id="disclaimer-details">
    <p>Подписка на &laquo;Демо контент&raquo; предоставляется контент-провайдером: ООО "Демо провайдер".</p>
			<p>Контактная информация контент-провайдера:</p>
			<p>Web-сайт:&nbsp;<a href='http://demo-provider.ru' target='_blank'>http://demo-provider.ru</a></p>
			<p>E-mail:&nbsp;<a href='mailto:support@demoprovider.ru' target='_blank'>support@demoprovider.ru</a></p>
			<p>Телефон:&nbsp;+7 (495) 123-45-67.</p>
			<p>С Правилами оказания услуги &laquo;Демо контент&raquo; Вы можете ознакомиться на сайте контент-провайдера <a href='http://demo-provider.ru' target='_blank'>http://demo-provider.ru</a>.<br/><br/>
			ОАО &laquo;МТС&raquo; предоставляет доступ к Подписке на &laquo;Демо контент&raquo; и не несет ответственности за качество 
			предоставляемой контент-провайдером Подписки на &laquo;Демо контент&raquo;, а также за информацию, размещаемую контент-провайдером на указанном сайте. 
			<br/><br/><strong>Важно!</strong> Если Вы заметили несоответствие условий оказания услуги, размещенных на данной странице, условиям оказания услуги, 
			размещенным на сайте контент-провайдера, просьба сообщить об этом по адресу <a href='mailto:moipodpiski@mts.ru'>moipodpiski@mts.ru</a>.</p>
</div>

        <div id="template-price"><span style="font-family:Arial !important;font-size:10px !important;">Стоимость 8,47 руб. с НДС за 1 день с основного счета МТС</span></div>
        <div id="template-caption"><span style="font-family:Arial !important;font-size:10px !important;">Нажатием кнопки «<span id="template-button-name">Получить доступ</span>» вы осуществляете заказ доступа к услуге «Демо контент», подтверждаете ознакомление и согласие с условиями его предоставления, <a href="http://static.mts.ru/uploadmsk/contents/1655/poryadok_predostavl_uslug_feb2013.pdf">Порядком предоставления контентных услуг ОАО «МТС»</a>, <a href="/#" onclick="window.location.href = LPCPOfferLink;return false;">правилами оказания услуги контент-провайдером ООО &quot;Демо провайдер&quot;</a>. Оказывается МТС с привлечением: ООО &quot;Демо провайдер&quot;. Списание будет производиться с основного счета +79161234567.</span></div>
<script type="text/javascript">
    if (top === self) { } else { window.top.location = self.location; }
</script>

<span style="display:none;">Correct response</span>


<?php include "footer.html"; ?>