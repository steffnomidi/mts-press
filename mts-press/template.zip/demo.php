<?php include "header.html"; ?>

<h1 id="subscr-name">Доступ к подписке
 &laquo;<span>Демо контент</span>&raquo;</h1>
<div id="subscr-price">Стоимость: <span>10 руб. с НДС за 1 день</span>. <br />Оказывается МТС с привлечением: <span>ООО &quot;Демо провайдер&quot;</span>. <br />Списание будет произведено с основного
 лицевого счета.</div>
<div id="subscr-msisdn">Ваш номер:&nbsp;<span id="msisdn">+79161234567</span></div>
<form id="subscr-form" method="post">
        <div id="submit-container">
        <label for="ButtonSubmit">Если Вы согласны с условиями оказания услуги, нажмите кнопку <b>«Получить доступ»</b></label>
        <div><input id="ButtonSubmit" type="submit" value="Получить доступ" onclick="if (!validateActivationForm()) { return false; };" /></div>
    </div>
    <input name="__RequestVerificationToken" type="hidden" value="jwq6MCeR2RNuc0ZU4S25n73qL_wgIdtdKJqPWwpEBMkd6OPMkQqP5pf-9nfeyPAK78yd2ZTuEstwsNv8-ushSHRxbnxydylX4s6bN4MaX7A1" />
</form>
<input id="sid" name="sid" type="hidden" value="00000000-0000-0000-0000-000000000000" /><div id="disclaimer-details">
    <p>Подписка на &laquo;Демо контент&raquo; предоставляется контент-провайдером: ООО "Демо провайдер".</p>
			<p>Контактная информация контент-провайдера:</p>
			<p>Web-сайт:&nbsp;<a href='http://demo-provider.ru' target='_blank'>http://demo-provider.ru</a></p>
			<p>E-mail:&nbsp;<a href='mailto:support@demoprovider.ru' target='_blank'>support@demoprovider.ru</a></p>
			<p>Телефон:&nbsp;+7 (495) 123-45-67.</p>
			<p>С Правилами оказания услуги &laquo;Демо контент&raquo; Вы можете ознакомиться на сайте контент-провайдера <a href='http://demo-provider.ru' target='_blank'>http://demo-provider.ru</a>.<br/><br/>
			ОАО &laquo;МТС&raquo; предоставляет доступ к Подписке на &laquo;Демо контент&raquo; и не несет ответственности за качество 
			предоставляемой контент-провайдером Подписки на &laquo;Демо контент&raquo;, а также за информацию, размещаемую контент-провайдером на указанном сайте. 
			<br/><br/><strong>Важно!</strong> Если Вы заметили несоответствие условий оказания услуги, размещенных на данной странице, условиям оказания услуги, 
			размещенным на сайте контент-провайдера, просьба сообщить об этом по адресу <a href='mailto:moipodpiski@mts.ru'>moipodpiski@mts.ru</a>.</p>
</div>

        <div id="template-price"><span style="font-family:Arial !important;font-size:10px !important;">Стоимость 10 руб. с НДС за 1 день с основного счета МТС</span></div>
        <div id="template-caption"><span style="font-family:Arial !important;font-size:10px !important;">Нажатием кнопки «<span id="template-button-name">Получить доступ</span>» вы осуществляете заказ доступа к услуге «Демо контент», подтверждаете ознакомление и согласие с условиями его предоставления, <a href="http://static.mts.ru/uploadmsk/contents/1655/poryadok_predostavl_uslug_feb2013.pdf">Порядком предоставления контентных услуг ОАО «МТС»</a>, <a href="/#" onclick="window.location.href = LPCPOfferLink;return false;">правилами оказания услуги контент-провайдером ООО &quot;Демо провайдер&quot;</a>. Оказывается МТС с привлечением: ООО &quot;Демо провайдер&quot;. Списание будет производиться с основного счета +79161234567.</span></div>
<script type="text/javascript">
    if (top === self) { } else { window.top.location = self.location; }
</script>

<span style="display:none;">Correct response</span>


<?php include "footer.html"; ?>